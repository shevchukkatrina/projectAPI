module.exports = (req, res, next) => {
    const start = process.hrtime();
    
    res.on('finish', () => {
      const diff = process.hrtime(start);
      const responseTime = diff[0] * 1e3 + diff[1] * 1e-6;
      console.log(`Запит ${req.method} ${req.originalUrl} зайняв ${responseTime.toFixed(2)}мс`);
    });
  
    next();
  };
  