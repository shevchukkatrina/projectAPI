const request = require('supertest');
const app = require('../app');
const pool = require('../models/db'); // Підключення до бази даних (якщо використовується MySQL)

// Очищення даних перед кожним тестом (для ізоляції тестів)
// beforeAll(async () => {   
//     // Створення тестового користувача (для GET тесту)
//     await pool.query('DELETE FROM users WHERE email = "test@b.com"');
//     await pool.query(`
//         INSERT INTO users (firstName, lastName, email) 
//         VALUES ("ExistingUser", "Test", "existing@b.com")
//     `);
// });

// // Закриття підключення після тестів
// afterAll(async () => {
//     await pool.query('DELETE FROM users WHERE email = "test@b.com"');
//     await pool.query('DELETE FROM users WHERE email = "existing@b.com"');
//     await pool.end();
// });

describe('GET /instructors', () => {
    it('повертає всіх користувачів', async () => {
        const res = await request(app).get('/instructors');
        expect(res.statusCode).toBe(200);
        expect(Array.isArray(res.body)).toBe(true);
        expect(res.body.length).toBeGreaterThanOrEqual(1); // Має бути хоча б один користувач
        expect(res.body[0]).toHaveProperty('first_name');
        expect(res.body[0]).toHaveProperty('last_name');
        expect(res.body[0]).toHaveProperty('middle_name');
    });
});

// describe('POST /users/new', () => {
//     it('додає нового користувача', async () => {
//         const res = await request(app).post('/users/new').send({
//             firstName: 'TestFirstName',
//             lastName: 'TestLastName',
//             email: 'test@b.com',
//         });
//         expect(res.statusCode).toBe(201);
//         expect(res.body).toHaveProperty('firstName', 'TestFirstName');
//         expect(res.body).toHaveProperty('lastName', 'TestLastName');
//         expect(res.body).toHaveProperty('email', 'test@b.com');
//     });

//     it('не дозволяє створити користувача з існуючим email', async () => {
//         const res = await request(app).post('/users/new').send({
//             firstName: 'DuplicateUser',
//             lastName: 'Test',
//             email: 'existing@b.com',
//         });
//         expect(res.statusCode).toBe(400); // Очікується помилка (наприклад, 400 Bad Request)
//         expect(res.body).toHaveProperty('error');
//     });
// });
