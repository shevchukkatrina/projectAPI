const express = require('express');
const { getInstructors, addInstructor } = require('../controllers/instructor.controller');

const router = express.Router();

/* GET users listing. */
router.get('/', getInstructors);

router.post('/new', addInstructor);

module.exports = router;
