const db = require('./db');

// constructor
// eslint-disable-next-line func-names
const Instructor = function (instructor) {
    this.id = instructor.id;
    this.first_name = instructor.first_name;
    this.last_name = instructor.last_name;
    this.middle_name = instructor.middle_name;
    this.phone = instructor.phone;
    this.address = instructor.address;
    this.birth_date = instructor.birth_date;
    this.start_date = instructor.start_date;
};

Instructor.getAll = async () => {
    const query = 'SELECT * FROM instructor';
    const rows = await db.query(query);
    return rows;
};

module.exports = Instructor;
